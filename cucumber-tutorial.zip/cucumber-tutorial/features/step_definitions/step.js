import { expect } from "chai";
import { Builder, By, until } from "selenium-webdriver";
import { When, Then, Given, setDefaultTimeout } from "@cucumber/cucumber";

setDefaultTimeout(30000);
let driver;

// 1. LOGIN FEATURE
Given("the user is on the login page", async function () {
  driver = new Builder().forBrowser("MicrosoftEdge").build();
  await driver.get("https://www.saucedemo.com/");
  await driver.sleep(1000);
});

When("the user enters a valid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("standard_user");
  await driver.findElement(By.id("password")).sendKeys("secret_sauce");
  await driver.sleep(1000);
});

When("the user clicks the login button", async function () {
  await driver.findElement(By.id("login-button")).click();
  await driver.sleep(1000);
});

Then("the user should see a success message", async function () {
  const message = await driver
    .wait(until.elementLocated(By.className("title")), 5000)
    .getText();
  expect(message).to.equal("Products");
  await driver.sleep(1000);
  
});

// 2. FAILED LOGIN FEATURE
When("the user enters an invalid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("invalid_user");
  await driver.findElement(By.id("password")).sendKeys("wrong_password");
  await driver.sleep(1000);
});

Then("the user should see a failed message", async function () {
  const error = await driver
    .wait(until.elementLocated(By.css("[data-test='error']")), 5000)
    .getText();
  expect(error).to.include("Username and password do not match");
  await driver.sleep(1000);
  await driver.quit();
});

// 3. ADD TO CART FEATURE
When("the user adds an item to the cart", async function () {
  await driver.wait(until.elementLocated(By.css('[data-test="add-to-cart-sauce-labs-backpack"]')), 5000).click();
  await driver.sleep(1000);
});

Then("the item should be visible in the cart page", async function () {
  await driver.findElement(By.className("shopping_cart_link")).click();
  await driver.sleep(1000);
  const cartItem = await driver.findElement(By.className("inventory_item_name")).getText();
  expect(cartItem).to.include("Backpack");
  await driver.sleep(1000);
  await driver.quit();
});

// 4. REMOVE FROM CART FEATURE
When("the user removes the item from the cart", async function () {
  await driver.findElement(By.className("shopping_cart_link")).click();
  await driver.sleep(1000);
  await driver.wait(until.elementLocated(By.css('[data-test="remove-sauce-labs-backpack"]')), 5000).click();
  await driver.sleep(1000);
});

Then("the item should no longer be in the cart page", async function () {
  const cartItems = await driver.findElements(By.className("inventory_item_name"));
  expect(cartItems.length).to.equal(0);
  await driver.sleep(1000);
  await driver.quit();
});

// 5. CHECKOUT FEATURE
When("the user goes to the cart and proceeds to checkout", async function () {
  await driver.findElement(By.className("shopping_cart_link")).click();
  await driver.sleep(1000);
  await driver.findElement(By.id("checkout")).click();
  await driver.sleep(1000);
});

When("the user fills in the required checkout information", async function () {
  await driver.findElement(By.id("first-name")).sendKeys("Test");
  await driver.findElement(By.id("last-name")).sendKeys("User");
  await driver.findElement(By.id("postal-code")).sendKeys("12345");
  await driver.sleep(1000);
  await driver.findElement(By.id("continue")).click();
  await driver.sleep(1000);
  await driver.findElement(By.id("finish")).click();
  await driver.sleep(1000);
});

Then("the user should see a confirmation message", async function () {
  const confirmation = await driver.findElement(By.className("complete-header")).getText();
  expect(confirmation.toLowerCase()).to.include("thank you for your order");
  await driver.sleep(1000);
  await driver.quit();
});

// 6. FILTER FEATURE
When("the user applies filter by lowest price", async function () {
  const dropdown = await driver.findElement(By.className("product_sort_container"));
  await dropdown.click();
  await dropdown.findElement(By.css('option[value="lohi"]')).click();
  await driver.sleep(1000);
});

Then("the items should be sorted from cheapest to most expensive", async function () {
  const prices = await driver.findElements(By.className("inventory_item_price"));
  let values = [];
  for (const p of prices) {
    const text = await p.getText();
    values.push(parseFloat(text.replace("$", "")));
  }
  for (let i = 0; i < values.length - 1; i++) {
    expect(values[i]).to.be.at.most(values[i + 1]);
  }
  await driver.sleep(1000);
  await driver.quit();
});
